# Email Spam Detector

A small Streamlit web app based on the pasted TF-IDF and Multinomial Naive Bayes example. It classifies a typed message and shows estimated class probabilities.

## Run locally

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Then open the local URL printed in the terminal.

## Publish from GitHub

1. Create a GitHub repository and upload these files (`app.py`, `requirements.txt`, and this README) to its root.
2. In Streamlit Community Cloud, choose **Create app**, select the repository and branch, and set the main file path to `app.py`.
3. Deploy. Streamlit Cloud will install packages from `requirements.txt`.

This demo uses only 30 sample messages. Its accuracy and probabilities should not be treated as reliable for real email filtering.
