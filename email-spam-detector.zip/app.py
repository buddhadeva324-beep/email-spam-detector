import pandas as pd
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix

st.set_page_config(page_title="Email Spam Detector", page_icon="📧")
st.title("📧 Email Spam Detector")
st.write("Enter a message to estimate whether it looks like spam.")

DATA = {
    "Category": ["spam"] * 15 + ["ham"] * 15,
    "Message": [
        "Congratulations you won 10000 rupees", "You won a lottery claim your prize now",
        "Free cash reward click here now", "Win a free gift today", "Urgent claim your cash prize",
        "Congratulations you are a lucky winner", "You won money click here", "Claim your free reward now",
        "Free prize waiting for you", "Win cash instantly now", "You have won 5000 rupees",
        "Claim your lottery reward immediately", "Free mobile recharge available now",
        "You are selected to win a cash prize", "Limited offer claim your free gift now",
        "Hi how are you", "Are you coming to college today", "Please send me the notes",
        "Lets meet tomorrow", "What time is the class", "I will call you later",
        "Please bring the project file", "Good morning have a nice day", "Where are you now",
        "Can we meet after college", "I am going to college today", "Please complete the assignment",
        "The meeting is at ten o clock", "Thank you for your help", "See you tomorrow",
    ],
}

@st.cache_resource
def train_model():
    df = pd.DataFrame(DATA)
    X_train, X_test, y_train, y_test = train_test_split(
        df["Message"], df["Category"], test_size=0.2, random_state=42, stratify=df["Category"]
    )
    vectorizer = TfidfVectorizer(lowercase=True, stop_words="english")
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)
    model = MultinomialNB().fit(X_train_vec, y_train)
    score = accuracy_score(y_test, model.predict(X_test_vec))
    matrix = confusion_matrix(y_test, model.predict(X_test_vec), labels=["ham", "spam"])
    return vectorizer, model, score, matrix

vectorizer, model, accuracy, matrix = train_model()
message = st.text_area("Message", placeholder="Paste or type a message…", height=140)
if st.button("Check message", type="primary", disabled=not message.strip()):
    features = vectorizer.transform([message.strip()])
    probabilities = model.predict_proba(features)[0]
    scores = dict(zip(model.classes_, probabilities))
    prediction = model.predict(features)[0]
    if prediction == "spam":
        st.error("🚨 Likely SPAM")
    else:
        st.success("✅ Likely HAM (not spam)")
    left, right = st.columns(2)
    left.metric("Spam probability", f"{scores.get('spam', 0) * 100:.1f}%")
    right.metric("Ham probability", f"{scores.get('ham', 0) * 100:.1f}%")

with st.expander("About this demo"):
    st.write("The classifier is trained on 30 sample messages, so its predictions are for demonstration only and may not generalize to real email.")
    st.metric("Holdout accuracy on this tiny sample", f"{accuracy * 100:.1f}%")
    st.write("Confusion matrix (rows: actual ham/spam; columns: predicted ham/spam):")
    st.dataframe(pd.DataFrame(matrix, index=["Actual ham", "Actual spam"], columns=["Predicted ham", "Predicted spam"]))
